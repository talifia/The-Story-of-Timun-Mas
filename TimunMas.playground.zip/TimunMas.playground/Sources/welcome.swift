import Foundation
import UIKit
import PlaygroundSupport

public class Welcome: UIView {
    var frameWidth = 750
    var frameHeight = 500
    
    //Sky
    let backgroundBG = UIImageView()
    let cloudBG = UIImageView()
    let fogBG = UIImageView()
    
    //BG Element
    let mountainBG = UIImageView()
    let rockBG = UIImageView()
    let titleView = UIImageView()
    let viewLantai = UIView()
    let whiteView = UIView()
    let sun = UIImageView()
    
    //Button
    let startButton = UIButton()
    
    public init(scene: UIView) {
        super.init(frame:CGRect(x: 0, y: 0, width: frameWidth, height: frameHeight))
        setupUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setupUI() {
        //sky
        backgroundBG.image = UIImage(named: "Sky/Sky.png")
        backgroundBG.frame = CGRect(x: 0, y: 0, width: frameWidth, height: frameHeight)
        backgroundBG.contentMode = .scaleToFill
        self.addSubview(backgroundBG)
        
        //sun
        sun.image = UIImage(named: "Sky/Sun.png")
        sun.frame = CGRect(x: 0, y: 50, width: 300, height: 300)
        sun.center = CGPoint(x: frameWidth/2, y: 100)
        sun.contentMode = .scaleToFill
        sun.alpha = 1
        self.addSubview(sun)
        
        //awan
        cloudBG.image = UIImage(named: "Sky/Clouds.png")
        cloudBG.frame = CGRect(x: 0, y: 50, width: frameWidth, height: 450)
        cloudBG.contentMode = .scaleToFill
        cloudBG.alpha = 1
        self.addSubview(cloudBG)
        
        
        //gunung
        mountainBG.image = UIImage(named: "Background/Mountains1.png")
        mountainBG.frame = CGRect(x: 0, y: 120, width: frameWidth, height: 220)
        mountainBG.contentMode = .scaleToFill
        mountainBG.alpha = 1
        self.addSubview(mountainBG)
        
        //fog
        fogBG.image = UIImage(named: "Sky/Fog.png")
        fogBG.frame = CGRect(x: 0,
                             y: 250, width: frameWidth, height: 250)
        fogBG.contentMode = .scaleToFill
        fogBG.alpha = 1
        self.addSubview(fogBG)
        
        //lantai
        viewLantai.frame = CGRect(x: 0, y: 370,width: frameWidth, height: 200)
        viewLantai.layer.backgroundColor = UIColor(red: 105/255.0,
                                                   green: 166/255.0,
                                                   blue: 89/255.0,
                                                   alpha: 1.0).cgColor
        self.addSubview(viewLantai)
        
        //titleview
        titleView.image = UIImage(named: "TitleView.png")
        titleView.frame = CGRect(x: 0, y: 0, width: 350, height: 100)
        titleView.contentMode = .scaleAspectFit
        titleView.center = CGPoint(x: frameWidth/2, y: frameHeight/2)
        titleView.alpha = 1
        self.addSubview(titleView)
        
        //rocks
        rockBG.image = UIImage(named: "Background/Rocks1.png")
        rockBG.frame = CGRect(x: 0, y: 350, width: frameWidth, height: 150)
        rockBG.contentMode = .scaleToFill
        rockBG.alpha = 1
        self.addSubview(rockBG)
        
        //start button
        startButton.setTitle("Let's start!", for: .normal)
        startButton.layer.backgroundColor = UIColor(red: 245/255.0,
                                                    green: 224/255.0,
                                                    blue: 163/255.0,
                                                    alpha: 1.0).cgColor
        startButton.frame = CGRect(x: 150, y: 180, width: 200, height: 40)
        startButton.center = CGPoint(x: frameWidth/2, y: 330)
        startButton.setTitleColor(.black, for: .normal)
        startButton.titleLabel?.font = UIFont.boldSystemFont(ofSize: 20)
        startButton.layer.shadowOpacity = 0.2
        startButton.layer.shadowRadius = 1.0
        startButton.layer.cornerRadius = 15.0
        startButton.addTarget(self, action: #selector(startButtonPressed), for: .touchUpInside)
        self.addSubview(startButton)
        
        //animate clouds
        UIView.animateKeyframes(withDuration: 2.0, delay: 0, options: [.autoreverse, .repeat]){
            self.cloudBG.frame = CGRect(x: 0, y: 70, width: 750, height: 450)}
        
    }
    
    @objc func startButtonPressed(sender: UIButton) {
        nextScreen()
    }
    
    func nextScreen() {
        self.pageFlipSound()
        self.playBgSound()
        self.removeFromSuperview()
        let introView = Introduction(scene: self)
        PlaygroundPage.current.liveView = introView
    }
}


