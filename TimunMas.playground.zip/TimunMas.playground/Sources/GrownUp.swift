import Foundation
import UIKit
import PlaygroundSupport

public class nextScene: UIView {
    var frameWidth = 750
    var frameHeight = 500
    
    //Background
    let backgroundBG = UIImageView()
    let cloudBG = UIImageView()
    let fogBG = UIImageView()
    
    //Elements
    let mountainBG = UIImageView()
    let rockBG = UIImageView()
    let viewLantai = UIView()
    let houseAndTrees = UIImageView()
    let bubbleSpeech = UIImageView()
    let bubbleSpeech2 = UIImageView()
    let dedaunan1 = UIImageView()
    let dedaunan2 = UIImageView()
    
    //people
    let mbokSirni = UIImageView()
    let butoIjo = UIImageView()
    let timunMas = UIImageView()
    
    //Button & text
    let nextButton = UIButton()
    let textLabel = UILabel()
    let textView = UIView()
    var introProcess = 0
    
    public init(scene: UIView) {
        super.init(frame:CGRect(x: 0, y: 0, width: frameWidth, height: frameHeight))
        setupUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setupUI() {
        //sky
        backgroundBG.image = UIImage(named: "Sky/Sky.png")
        backgroundBG.frame = CGRect(x: 0, y: 0, width: frameWidth, height: frameWidth)
        backgroundBG.contentMode = .scaleToFill
        self.addSubview(backgroundBG)
        
        //awan
        cloudBG.image = UIImage(named: "Sky/Clouds.png")
        cloudBG.frame = CGRect(x: 0, y: 50, width: frameWidth, height: 450)
        cloudBG.contentMode = .scaleToFill
        self.addSubview(cloudBG)
        
        //gunung
        mountainBG.image = UIImage(named: "Background/Mountains1.png")
        mountainBG.frame = CGRect(x: 0, y: 160, width: frameWidth, height: 220)
        mountainBG.contentMode = .scaleToFill
        self.addSubview(mountainBG)
        
        //fog
        fogBG.image = UIImage(named: "Sky/Fog.png")
        fogBG.frame = CGRect(x: 0,
                             y: 270, width: frameWidth, height: 250)
        fogBG.contentMode = .scaleToFill
        self.addSubview(fogBG)
        
        //house & trees
        houseAndTrees.image = UIImage(named: "Background/HouseTrees.png")
        houseAndTrees.frame = CGRect(x: 50, y: 170, width: 650, height: 220)
        houseAndTrees.contentMode = .scaleToFill
        self.addSubview(houseAndTrees)
        
        //lantai
        viewLantai.frame = CGRect(x: 0, y: 380,width: frameWidth, height: 200)
        viewLantai.layer.backgroundColor = UIColor(red: 105/255.0,
                                                   green: 166/255.0,
                                                   blue: 89/255.0,
                                                   alpha: 1.0).cgColor
        self.addSubview(viewLantai)
        
        
        //mbok sirni
        mbokSirni.image = UIImage(named: "Characters/MbokSirni_happy.png")
        mbokSirni.frame = CGRect(x: 370,
                                 y: 230, width: 110, height: 220)
        mbokSirni.center = CGPoint (x: 400, y: 320)
        mbokSirni.contentMode = .scaleToFill
        mbokSirni.alpha = 0
        self.addSubview(mbokSirni)
        
        //bubble speech2
        bubbleSpeech2.image = UIImage(named: "Elements/bubbleSpeech3.png")
        bubbleSpeech2.frame = CGRect(x: 335,
                                     y: 170, width: 140, height: 120)
        bubbleSpeech2.center = CGPoint(x: 500, y: 250)
        bubbleSpeech2.contentMode = .scaleToFill
        bubbleSpeech2.alpha = 0
        self.addSubview(bubbleSpeech2)
        
        //buto ijo
        butoIjo.image = UIImage(named: "ButoIjo1.png")
        butoIjo.transform = CGAffineTransform(scaleX: -1, y: 1); //Flipped
        butoIjo.frame = CGRect(x: 50,
                               y: 150, width: 200, height: 300)
        butoIjo.contentMode = .scaleToFill
        butoIjo.alpha = 0
        self.addSubview(butoIjo)
        
        //bubble speech
        bubbleSpeech.image = UIImage(named: "Elements/BubbleSpeech2.png")
        bubbleSpeech.frame = CGRect(x: 335,
                                    y: 170, width: 140, height: 120)
        bubbleSpeech.center = CGPoint(x: 340, y: 110)
        bubbleSpeech.contentMode = .scaleToFill
        bubbleSpeech.alpha = 0
        self.addSubview(bubbleSpeech)
        
        
        //timun mas
        timunMas.image = UIImage(named: "Characters/TimunMas_happy.png")
        timunMas.frame = CGRect(x: 370,
                                y: 230, width: 100, height: 200)
        timunMas.center = CGPoint (x: 320, y: 340)
        timunMas.contentMode = .scaleToFill
        timunMas.alpha = 0
        self.addSubview(timunMas)
        
        //rocks
        rockBG.image = UIImage(named: "Background/rock_pond.png")
        rockBG.frame = CGRect(x: 0, y: 350, width: frameWidth, height: 150)
        rockBG.contentMode = .scaleToFill
        self.addSubview(rockBG)
        
        //text view
        textView.frame = CGRect(x: 0, y: 380,width: 650, height: 80)
        textView.center = CGPoint(x: frameWidth/2, y: 440)
        textView.backgroundColor = .white
        textView.layer.cornerRadius = 30.0
        textView.alpha = 1
        self.addSubview(textView)
        
        //text
        textLabel.text = "Years passed and Timun Emas is finally 17 years old. Timun Emas has grew to become a lovely and beautiful little girl. She was also smart and kind. Mbok Sirni loved her very much. But she kept thinking about the time Buto Ijo would take Timun Emas away from her."
        textLabel.textAlignment = NSTextAlignment.center
        textLabel.textColor = UIColor.black
        textLabel.numberOfLines = 0
        textLabel.frame = CGRect(x: 20, y: 35, width: 600, height: 70)
        textLabel.center = CGPoint(x: frameWidth/2, y: 440)
        textLabel.font = UIFont(name: "Arial", size: 14.5)
        textLabel.alpha = 0
        self.addSubview(textLabel)
        
        //next button
        nextButton.setTitle("Next!", for: .normal)
        nextButton.layer.backgroundColor = UIColor(red: 245/255.0,
                                                   green: 224/255.0,
                                                   blue: 163/255.0,
                                                   alpha: 1.0).cgColor
        nextButton.frame = CGRect(x: 150, y: 180, width: 80, height: 30)
        nextButton.center = CGPoint(x: 650, y: 470)
        nextButton.setTitleColor(.black, for: .normal)
        nextButton.titleLabel?.font = UIFont.boldSystemFont(ofSize: 14)
        nextButton.layer.shadowOpacity = 0.2
        nextButton.layer.shadowRadius = 1.0
        nextButton.layer.cornerRadius = 15.0
        nextButton.addTarget(self, action: #selector(startButtonPressed), for: .touchUpInside)
        nextButton.alpha = 0
        self.addSubview(nextButton)
        
        UIView.animateKeyframes(withDuration: 2.0, delay: 0, options: [.autoreverse, .repeat]){
            self.cloudBG.frame = CGRect(x: 0, y: 70, width: 750, height: 450)}
        
        animateTimunMas()
        animateMbokSirni()
        animateScene()
        
    }
    
    //func animate instro
    func animateScene() {
        if(introProcess == 0)  {
            UIView.animate(withDuration: 1, delay: 0.5, options: .curveEaseOut, animations: {
                self.textLabel.alpha = 1
            })
            { (completion) in
                Timer.scheduledTimer(withTimeInterval: 5, repeats: false, block: { (time) in
                    self.introProcess = 1
                    self.animateScene()
                    self.animateButoIjo()
                })
            }
        } // if
        if(introProcess == 1) {
            //timun mas ilang
            UIView.animate(withDuration: 1, delay: 0, options: .curveEaseOut, animations: {
                self.timunMas.alpha = 0
            })
            
            //mbok sirni kaget
            mbokSirni.image = UIImage(named: "Characters/MbokSarmiPraying.png")
            mbokSirni.frame = CGRect(x: 170,
                                     y: 220, width: 100, height: 220)
            mbokSirni.center = CGPoint (x: 400, y: 320)
            mbokSirni.transform = CGAffineTransform(scaleX: -1, y: 1); //Flipped
            
            //animate text
            UIView.animate(withDuration: 4, delay: 0, options: .curveEaseOut, animations: {
                self.textLabel.alpha = 0
            }, completion: nil)
            self.animateBubbleSpeech()
            UIView.animate(withDuration: 3.5, delay: 0, options: .curveEaseOut, animations: {
                self.textLabel.alpha = 1
                self.textLabel.text = " However, just a few days after Timun Mas turned 17, Buto Ijo came to see Mbok Sirni about her promise. “Mbok Sirni! Where is Timun Emas?” shouted the giant. Mbok Sirni asked for more days to hand Timun Mas."
            })
            { (completion) in
                Timer.scheduledTimer(withTimeInterval: 5, repeats: false, block: { (time) in
                    self.animateButoIjoOut()
                    self.animateBubbleSpeechOut()
                    self.animateBubbleSpeech2()
                    self.introProcess = 2
                    self.animateScene()
                })
            }
        } // if
        if(introProcess == 2) {
            //timun mas masuk lagi
            UIView.animate(withDuration: 1, delay: 0.5, options: .curveEaseOut, animations: {
                self.timunMas.image = UIImage(named: "Characters/TimunMas_sad.png")
                self.timunMas.alpha = 1
            })
            
            UIView.animate(withDuration: 1.5, delay: 0, options: .curveEaseOut, animations: {
                self.textLabel.alpha = 0
            }, completion: nil)
            UIView.animate(withDuration: 3, delay: 0, options: .curveEaseOut, animations: {
                self.textLabel.alpha = 1
                self.textLabel.text = "With tears, Mbok Sirni told Timun Mas to escape. “You have to escape before Buto Ijo comes back.” She then told Timun Mas to get something from the house. “Daughter, go inside and get some items I prepared for you. It would help you survive.”"
            })
            { (completion) in
                Timer.scheduledTimer(withTimeInterval: 2.5, repeats: false, block: { (time) in
                    self.introProcess = 3
                    self.nextButton.alpha = 1
                })
            }
        }
    } // animate intro
    
    //animate buto ijo in
    func animateButoIjo() {
        self.butoIjoSound()
        UIView.animate(withDuration: 1.0, delay: 0.5, usingSpringWithDamping: 1.0, initialSpringVelocity: 1.0, options: UIView.AnimationOptions.curveEaseIn, animations: ({
            self.butoIjo.frame = CGRect(x: 150,
                                        y: 150, width: 200, height: 300)
            self.butoIjo.alpha = 1
        }))
    }
    
    //animate buto ijo out
    func animateButoIjoOut() {
        UIView.animate(withDuration: 1.0, delay: 0, usingSpringWithDamping: 1.0, initialSpringVelocity: 1.0, options: UIView.AnimationOptions.curveEaseOut, animations: ({
            self.butoIjo.frame = CGRect(x: 150,
                                        y: 150, width: 200, height: 300)
            self.butoIjo.alpha = 0
        }))
    }
    
    // bubble speech in
    func animateBubbleSpeech() {
        UIView.animate(withDuration: 1.0, delay: 0.5, usingSpringWithDamping: 1.0, initialSpringVelocity: 1.0, options: UIView.AnimationOptions.curveEaseIn, animations: ({
            self.bubbleSpeech.frame = CGRect(x: 335,
                                             y: 170, width: 140, height: 120)
            self.bubbleSpeech.center = CGPoint(x: 340, y: 110)
            self.bubbleSpeech.alpha = 1
        }))
    }
    
    // bubble speech out
    func animateBubbleSpeechOut() {
        UIView.animate(withDuration: 1.0, delay: 0, usingSpringWithDamping: 1.0, initialSpringVelocity: 1.0, options: UIView.AnimationOptions.curveEaseOut, animations: ({
            self.bubbleSpeech.frame = CGRect(x: 335,
                                             y: 140, width: 140, height: 120)
            self.bubbleSpeech.center = CGPoint(x: 340, y: 110)
            self.bubbleSpeech.alpha = 0
        }))
    }
    
    // bubble speech in
    func animateBubbleSpeech2() {
        UIView.animate(withDuration: 1.0, delay: 0.5, usingSpringWithDamping: 1.0, initialSpringVelocity: 1.0, options: UIView.AnimationOptions.curveEaseIn, animations: ({
            self.bubbleSpeech2.frame = CGRect(x: 335,
                                              y: 170, width: 140, height: 120)
            self.bubbleSpeech2.center = CGPoint(x: 500, y: 250)
            self.bubbleSpeech2.alpha = 1
        }))
    }
    
    // bubble speech out
    func animateBubbleSpeechOut2() {
        UIView.animate(withDuration: 1.0, delay: 0, usingSpringWithDamping: 1.0, initialSpringVelocity: 1.0, options: UIView.AnimationOptions.curveEaseOut, animations: ({
            self.bubbleSpeech2.frame = CGRect(x: 335,
                                              y: 170, width: 140, height: 120)
            self.bubbleSpeech2.center = CGPoint(x: 500, y: 250)
            self.bubbleSpeech2.alpha = 0
        }))
    }
    
    func animateTimunMas() {
        UIView.animate(withDuration: 1.0, delay: 0.5, usingSpringWithDamping: 1.0, initialSpringVelocity: 1.0, options: UIView.AnimationOptions.curveEaseIn, animations: ({
            self.timunMas.frame = CGRect(x: 370,
                                         y: 230, width: 100, height: 200)
            self.timunMas.center = CGPoint (x: 320, y: 340)
            self.timunMas.alpha = 1
        }))
    }
    
    func animateMbokSirni() {
        UIView.animate(withDuration: 1.0, delay: 0.5, usingSpringWithDamping: 1.0, initialSpringVelocity: 1.0, options: UIView.AnimationOptions.curveEaseIn, animations: ({
            self.mbokSirni.frame = CGRect(x: 370,
                                          y: 230, width: 110, height: 220)
            self.mbokSirni.center = CGPoint (x: 400, y: 320)
            self.mbokSirni.alpha = 1
        }))
    }
    
    @objc func startButtonPressed(sender: UIButton) {
        nextScreen()
    }
    
    func nextScreen() {
        self.removeFromSuperview()
        let nextScreenView = PickGame2(scene: self)
        PlaygroundPage.current.liveView = nextScreenView
    }
}
