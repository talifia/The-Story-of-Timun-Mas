import Foundation
import UIKit
import PlaygroundSupport

public class Congrats: UIView {
    var frameWidth = 750
    var frameHeight = 500
    
    //Background
    let backgroundBG = UIImageView()
    
    //people
    let timunMas = UIImageView()
    let happyFamily = UIImageView()
    
    //Button & text
    let nextButton = UIButton()
    let textLabel = UILabel()
    let textLabel2 = UILabel()
    var introProcess = 0
    
    
    public init(scene: UIView) {
        super.init(frame:CGRect(x: 0, y: 0, width: frameWidth, height: frameHeight))
        setupUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setupUI() {
        backgroundBG.backgroundColor = .init(red: 242.0/255.0, green: 233.0/255.0, blue: 207.0/255.0, alpha: 100.0)
        backgroundBG.frame = CGRect(x: 0, y: 0, width: frameWidth, height: frameWidth)
        backgroundBG.contentMode = .scaleToFill
        self.addSubview(backgroundBG)
        
        //text
        textLabel.text = "Congrats! you have defeated Buto Ijo!"
        textLabel.textAlignment = NSTextAlignment.center
        textLabel.textColor = UIColor.black
        textLabel.numberOfLines = 0
        textLabel.frame = CGRect(x: 0, y: 35, width: 600, height: 70)
        textLabel.center = CGPoint(x: frameWidth/2, y: 50)
        textLabel.font = UIFont.boldSystemFont(ofSize: 14)
        textLabel.alpha = 1
        self.addSubview(textLabel)
        
        //timun mas happy!
        timunMas.image = UIImage(named: "Characters/TimunMas_excited.png")
        timunMas.frame = CGRect(x: 370,
                                y: 230, width: 150, height: 250)
        timunMas.center = CGPoint (x: frameWidth/2, y: frameHeight/2)
        timunMas.contentMode = .scaleToFill
        timunMas.alpha = 1
        self.addSubview(timunMas)
        
        //timun mas happy!
        happyFamily.image = UIImage(named: "Characters/happyFamily.png")
        happyFamily.frame = CGRect(x: 370,
                                   y: 230, width: 400, height: 250)
        happyFamily.center = CGPoint (x: frameWidth/2, y: frameHeight/2)
        happyFamily.contentMode = .scaleToFill
        happyFamily.alpha = 0
        self.addSubview(happyFamily)
        
        //next button
        nextButton.setTitle("Play Again!", for: .normal)
        nextButton.layer.backgroundColor = UIColor(red: 245/255.0,
                                                   green: 224/255.0,
                                                   blue: 163/255.0,
                                                   alpha: 1.0).cgColor
        nextButton.frame = CGRect(x: 150, y: 180, width: 140, height: 30)
        nextButton.center = CGPoint(x: 650, y: 470)
        nextButton.setTitleColor(.black, for: .normal)
        nextButton.titleLabel?.font = UIFont.boldSystemFont(ofSize: 14)
        nextButton.layer.shadowOpacity = 0.2
        nextButton.layer.shadowRadius = 1.0
        nextButton.layer.cornerRadius = 15.0
        nextButton.addTarget(self, action: #selector(startButtonPressed), for: .touchUpInside)
        nextButton.alpha = 1
        self.addSubview(nextButton)
        
        animateTimunMasOut()
        animateHappyFamily()
        animatetext()
    }
    
    func animateTimunMasOut() {
        UIView.animate(withDuration: 0.3, delay: 2, usingSpringWithDamping: 1.0, initialSpringVelocity: 1.0, options: UIView.AnimationOptions.curveEaseOut, animations: ({
            self.timunMas.frame = CGRect(x: 370,
                                         y: 230, width: 150, height: 250)
            self.timunMas.center = CGPoint (x: self.frameWidth/2, y: self.frameHeight/2)
            self.timunMas.alpha = 0
        }))
    }
    
    func animateHappyFamily() {
        UIView.animate(withDuration: 0.3, delay: 2, usingSpringWithDamping: 1.0, initialSpringVelocity: 1.0, options: UIView.AnimationOptions.curveEaseIn, animations: ({
            self.happyFamily.frame = CGRect(x: 370,
                                            y: 230, width: 300, height: 320)
            self.happyFamily.center = CGPoint (x: self.frameWidth/2, y: self.frameHeight/2)
            self.happyFamily.alpha = 1
        }))
    }
    
    func animatetext() {
        UIView.animate(withDuration: 0.3, delay: 2, usingSpringWithDamping: 1.0, initialSpringVelocity: 1.0, options: UIView.AnimationOptions.curveEaseIn, animations: ({
            self.textLabel.text = "Timun Mas & Mbok Sirni can finally live happily ever after."
            self.textLabel.frame = CGRect(x: 0, y: 35, width: 600, height: 70)
            self.textLabel.center = CGPoint(x: self.frameWidth/2, y: 50)
            self.textLabel.alpha = 1
        }))
    }
    
    
    @objc func startButtonPressed(sender: UIButton) {
        nextScreen()
    }
    
    func nextScreen() {
        //                //naro lagu
        ////                self.playBgSound()
        //
        self.removeFromSuperview()
        let nextScreenView = Welcome(scene: self)
        PlaygroundPage.current.liveView = nextScreenView
    }
}
