import UIKit
import AVFoundation

var soundURI: URL?
var audioPlayer = AVAudioPlayer()
var bgSoundURI: URL?
var bgAudioPlayer = AVAudioPlayer()
var battleAudioPlayer = AVAudioPlayer()

extension UIView {
    
    func playSound(file: String, fileExtension: String, isLoop: Bool = false){
        soundURI = URL(fileURLWithPath: Bundle.main.path(forResource: file, ofType: fileExtension)!)
        do {
            guard let uri = soundURI else {return}
            audioPlayer = try AVAudioPlayer(contentsOf: uri)
            audioPlayer.play()
        } catch {
            print("something went wrong")
        }
    }
    
    func pageFlipSound() {
        self.playSound(file: "VN_page flip", fileExtension: "m4a")
    }
    
    func pourSound() {
        self.playSound(file: "VN_water pouring", fileExtension: "m4a")
    }
    
    func suspenseSound() {
        self.playSound(file: "Suspense", fileExtension: "mp3")
    }
    
    func butoIjoSound() {
        self.playSound(file: "VN_Buto Ijo Laughing", fileExtension: "m4a")
    }
    
    func clickSound() {
        self.playSound(file: "VN_click", fileExtension: "m4a")
    }
    
    func waterkSound() {
        self.playSound(file: "Water Sound", fileExtension: "mp3")
    }
    
    func cheeringSound() {
        self.playSound(file: "kids_cheering_imovie", fileExtension: "mp3")
    }
    
    func playBattleSound(){
        bgSoundURI = URL(fileURLWithPath: Bundle.main.path(forResource: "Untitled - 19_04_21 17.54", ofType: "m4a")!)
        do {
            guard let uri = bgSoundURI else {return}
            battleAudioPlayer = try AVAudioPlayer(contentsOf: uri)
            battleAudioPlayer.numberOfLoops = -1
            battleAudioPlayer.volume = 0.5
            battleAudioPlayer.play()
        } catch {
            print("something went wrong")
        }
    }
    
    func stopBattleSound() {
        battleAudioPlayer.stop()
    }
    
    func playBgSound(){
        bgSoundURI = URL(fileURLWithPath: Bundle.main.path(forResource: "Project - 18_04_21 20.03", ofType: "m4a")!)
        do {
            guard let uri = bgSoundURI else {return}
            bgAudioPlayer = try AVAudioPlayer(contentsOf: uri)
            bgAudioPlayer.numberOfLoops = -1
            bgAudioPlayer.volume = 0.5
            bgAudioPlayer.play()
        } catch {
            print("something went wrong")
        }
    }
    
    func stopBgSound() {
        bgAudioPlayer.stop()
    }
}



