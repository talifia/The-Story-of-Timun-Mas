import Foundation
import UIKit
import PlaygroundSupport

public class Fight2: UIView {
    var frameWidth = 750
    var frameHeight = 500
    
    //Background
    let backgroundBG = UIImageView()
    let cloudBG = UIImageView()
    let fogBG = UIImageView()
    
    //Elements
    let mountainBG = UIImageView()
    let rockBG = UIImageView()
    let viewLantai = UIView()
    let houseAndTrees = UIImageView()
    let bubbleSpeech = UIImageView()
    let bambooField1 = UIImageView()
    let bambooField2 = UIImageView()
    
    //people
    let butoIjo = UIImageView()
    let timunMas = UIImageView()
    
    //Button & text
    let nextButton = UIButton()
    let nextButton2 = UIButton()
    let saltButton = UIButton()
    let needlesButton = UIButton()
    let textLabel = UILabel()
    let textView = UIView()
    
    public init(scene: UIView) {
        super.init(frame:CGRect(x: 0, y: 0, width: frameWidth, height: frameHeight))
        setupUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setupUI() {
        //sky
        backgroundBG.image = UIImage(named: "Sky/Sky5.png")
        backgroundBG.frame = CGRect(x: 0, y: 0, width: frameWidth, height: frameWidth)
        backgroundBG.contentMode = .scaleToFill
        self.addSubview(backgroundBG)
        
        //awan
        cloudBG.image = UIImage(named: "Sky/Clouds.png")
        cloudBG.frame = CGRect(x: 0, y: 50, width: frameWidth, height: 450)
        cloudBG.contentMode = .scaleToFill
        self.addSubview(cloudBG)
        
        
        //fog
        fogBG.image = UIImage(named: "Sky/Fog.png")
        fogBG.frame = CGRect(x: 0,
                             y: 270, width: frameWidth, height: 250)
        fogBG.contentMode = .scaleToFill
        self.addSubview(fogBG)
        
        
        //gunung
        mountainBG.image = UIImage(named: "Background/mountains2.png")
        mountainBG.frame = CGRect(x: 0, y: 0, width: 1000, height: 500)
        mountainBG.center = CGPoint(x: frameWidth/2, y: 150)
        mountainBG.contentMode = .scaleToFill
        self.addSubview(mountainBG)
        
        //trees
        houseAndTrees.image = UIImage(named: "Background/trees.png")
        houseAndTrees.frame = CGRect(x: 0, y: 200, width: frameWidth, height: 220)
        houseAndTrees.contentMode = .scaleToFill
        self.addSubview(houseAndTrees)
        
        //lantai
        viewLantai.frame = CGRect(x: 0, y: 380,width: frameWidth, height: 120)
        viewLantai.layer.backgroundColor = UIColor(red: 85/255.0,
                                                   green: 142/255.0,
                                                   blue: 153/255.0,
                                                   alpha: 1.0).cgColor
        self.addSubview(viewLantai)
        
        //text
        textLabel.text = "The cucumber seeds does not work, let's use other items! \n Click the needles to see what happens!"
        textLabel.textAlignment = NSTextAlignment.center
        textLabel.textColor = UIColor.black
        textLabel.numberOfLines = 0
        textLabel.frame = CGRect(x: 0, y: 35, width: 600, height: 70)
        textLabel.center = CGPoint(x: frameWidth/2, y: 50)
        textLabel.font = UIFont.boldSystemFont(ofSize: 14)
        textLabel.alpha = 1
        self.addSubview(textLabel)
        
        
        //timun mas
        timunMas.image = UIImage(named: "Characters/TimunMas_back.png")
        timunMas.frame = CGRect(x: 340,
                                y: 230, width: 100, height: 200)
        timunMas.center = CGPoint (x: 170, y: 340)
        timunMas.contentMode = .scaleToFill
        timunMas.alpha = 0
        self.addSubview(timunMas)
        
        //cucumber field 1
        bambooField1.image = UIImage(named: "Background/bamboo_field1.png")
        bambooField1.frame = CGRect (x: 0, y: 250, width: 800, height: 350)
        bambooField1.contentMode = .scaleToFill
        bambooField1.alpha = 0
        self.addSubview(bambooField1)
        
        //buto ijo
        butoIjo.image = UIImage(named: "Characters/ButoIjo2.png")
        butoIjo.frame = CGRect(x: 370,
                               y: 130, width: 260, height: 300)
        butoIjo.contentMode = .scaleToFill
        butoIjo.alpha = 0
        self.addSubview(butoIjo)
        
        //cucumber field 2
        bambooField2.image = UIImage(named: "Background/bamboo_field2.png")
        bambooField2.frame = CGRect (x: 0, y: 300, width: 800, height: 350)
        bambooField2.contentMode = .scaleToFill
        bambooField2.alpha = 0
        self.addSubview(bambooField2)
        
        
        //cucumber
        needlesButton.setImage(UIImage(named: "Elements/needles.png"), for: .normal)
        needlesButton.frame = CGRect(x: 100,
                                     y: 150, width: 50, height: 50)
        needlesButton.isEnabled = false
        needlesButton.isHidden = true
        needlesButton.layer.shadowOpacity = 0.2
        needlesButton.layer.shadowRadius = 1.0
        needlesButton.addTarget(self, action: #selector(cucumberButtonPressed), for: .touchUpInside)
        self.addSubview(needlesButton)
        
        
        //next button
        nextButton.setTitle("Use the next item", for: .normal)
        nextButton.layer.backgroundColor = UIColor(red: 245/255.0,
                                                   green: 224/255.0,
                                                   blue: 163/255.0,
                                                   alpha: 1.0).cgColor
        nextButton.frame = CGRect(x: 150, y: 180, width: 150, height: 30)
        nextButton.center = CGPoint(x: 630, y: 470)
        nextButton.setTitleColor(.black, for: .normal)
        nextButton.titleLabel?.font = UIFont.boldSystemFont(ofSize: 14)
        nextButton.layer.shadowOpacity = 0.2
        nextButton.layer.shadowRadius = 1.0
        nextButton.layer.cornerRadius = 15.0
        nextButton.addTarget(self, action: #selector(startButtonPressed), for: .touchUpInside)
        nextButton.alpha = 0
        self.addSubview(nextButton)
        
        UIView.animateKeyframes(withDuration: 2.0, delay: 0, options: [.autoreverse, .repeat]){
            self.cloudBG.frame = CGRect(x: 0, y: 70, width: 750, height: 450)}
        
        animateNarrative()
        animateTimunMas()
        animateButoIjo()
        
        
    }
    
    func animateNarrative(){
        self.needlesButton.isEnabled = true
        self.needlesButton.isHidden = false
        UIView.animate(withDuration: 1.0, delay: 0.5, usingSpringWithDamping: 1.0, initialSpringVelocity: 1.0, options: UIView.AnimationOptions.curveEaseIn, animations: ({
            self.timunMas.frame = CGRect(x: 370,
                                         y: 230, width: 100, height: 200)
            self.timunMas.center = CGPoint (x: 170, y: 340)
            self.timunMas.alpha = 1
        }))
        
        
    }
    
    func animateScene() {
        self.suspenseSound()
        animateButoIjo2()
        animateTimunMasOut()
        animateCucumberField()
        self.needlesButton.isHidden = true
        self.needlesButton.isHidden = true
        self.textLabel.text = "The needles turned into bamboo trees, sharp and thorny. Buto Ijo’s body was scratched and bled. However, he managed to get out and still chasing Timun Mas."
        self.timunMas.alpha = 0
        self.nextButton.alpha = 1
    }// animate what happened
    
    //animate timun mas
    func animateTimunMas() {
        UIView.animate(withDuration: 1.0, delay: 0.5, usingSpringWithDamping: 1.0, initialSpringVelocity: 1.0, options: UIView.AnimationOptions.curveEaseIn, animations: ({
            self.timunMas.frame = CGRect(x: 370,
                                         y: 230, width: 100, height: 200)
            self.timunMas.center = CGPoint (x: 170, y: 340)
            self.timunMas.alpha = 1
        }))
    }
    
    //animate timun mas out
    func animateTimunMasOut() {
        UIView.animate(withDuration: 0.3, delay: 0, usingSpringWithDamping: 1.0, initialSpringVelocity: 1.0, options: UIView.AnimationOptions.curveEaseOut, animations: ({
            self.timunMas.frame = CGRect(x: 370,
                                         y: 230, width: 100, height: 200)
            self.timunMas.center = CGPoint (x: 170, y: 340)
            self.timunMas.alpha = 1
        }))
    }
    
    //animate buto ijo in
    func animateButoIjo() {
        UIView.animate(withDuration: 1.0, delay: 1, usingSpringWithDamping: 1.0, initialSpringVelocity: 1.0, options: UIView.AnimationOptions.curveEaseIn, animations: ({
            self.butoIjo.frame = CGRect(x: 340,
                                        y: 130, width: 260, height: 300)
            self.butoIjo.alpha = 1
        }))
    }
    
    //animate buto ijo in
    func animateButoIjo2() {
        UIView.animate(withDuration: 1.0, delay: 0, usingSpringWithDamping: 1.0, initialSpringVelocity: 1.0, options: UIView.AnimationOptions.curveEaseIn, animations: ({
            self.butoIjo.frame = CGRect(x: 200,
                                        y: 100, width: 300, height: 340)
            self.butoIjo.alpha = 1
        }))
    }
    
    //animate cucumberfield
    func animateCucumberField() {
        UIView.animate(withDuration: 1.0, delay: 0, usingSpringWithDamping: 1.0, initialSpringVelocity: 1.0, options: UIView.AnimationOptions.curveEaseIn, animations: ({
            self.bambooField1.frame = CGRect (x: -25, y: 100, width: 800, height: 500)
            self.bambooField1.alpha = 1
            self.bambooField2.frame = CGRect (x: -25, y: 200, width: 800, height: 500)
            self.bambooField2.alpha = 1
            
        }))
    }
    
    
    // bubble speech in
    func animateBubbleSpeech() {
        UIView.animate(withDuration: 1.0, delay: 1, usingSpringWithDamping: 1.0, initialSpringVelocity: 1.0, options: UIView.AnimationOptions.curveEaseIn, animations: ({
            self.bubbleSpeech.frame = CGRect(x: 335,
                                             y: 170, width: 140, height: 120)
            self.bubbleSpeech.center = CGPoint(x: 600, y: 100)
            self.bubbleSpeech.alpha = 1
        }))
    }
    
    @objc func startButtonPressed(sender: UIButton) {
        nextScreen()
    }
    
    
    @objc func cucumberButtonPressed(sender: UIButton) {
        animateScene()
    }
    
    func nextScreen() {
        //                //naro lagu
        ////                self.playBgSound()
        //
        self.removeFromSuperview()
        let nextScreenView = Fight3(scene: self)
        PlaygroundPage.current.liveView = nextScreenView
    }
}
