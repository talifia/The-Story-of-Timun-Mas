import Foundation
import UIKit
import PlaygroundSupport

public class PickGame2: UIView {
    var frameWidth = 750
    var frameHeight = 500
    
    //Background
    let backgroundBG = UIImageView()
    
    //Elements
    let biji = UIImageView()
    let pouch = UIImageView()
    let gayung = UIImageView()
    let rak = UIImageView()
    let needles = UIImageView()
    let salt = UIImageView()
    let pisau = UIImageView()
    let ayam = UIImageView()
    let listLabel = UIImageView()
    
    //people
    let timunMas = UIImageView()
    
    //Button & text
    let nextButton = UIButton()
    let textLabel = UILabel()
    let textLabel2 = UILabel()
    
    //location
    let cucumberLocation = CGPoint(x: 350, y: 130)
    let NeedlesLocation = CGPoint(x: 650, y: 130)
    let saltLocation = CGPoint(x: 500, y: 250)
    
    //process
    var stepProcess = 1
    
    //others
    //    var isDraggingBlock = 0
    //    var introProcess = 0
    //    var isCucumberPoured = false
    //    var isNeedlesPoured = false
    //    var isSaltPoured = false
    
    
    public init(scene: UIView) {
        super.init(frame:CGRect(x: 0, y: 0, width: frameWidth, height: frameHeight))
        setupUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setupUI() {
        backgroundBG.backgroundColor = .init(red: 242.0/255.0, green: 233.0/255.0, blue: 207.0/255.0, alpha: 100.0)
        backgroundBG.frame = CGRect(x: 0, y: 0, width: frameWidth, height: frameWidth)
        backgroundBG.contentMode = .scaleToFill
        self.addSubview(backgroundBG)
        
        //label list
        listLabel.image = UIImage(named: "Elements/speech.png")
        listLabel.frame = CGRect(x:50, y:100, width: 180, height: 100)
        listLabel.center = CGPoint(x: 130, y: 180)
        listLabel.contentMode = .scaleToFill
        self.addSubview(listLabel)
        
        
        //timun mas
        timunMas.image = UIImage(named: "Characters/TimunMas_mad.png")
        timunMas.frame = CGRect(x: 80,
                                y: 270, width: 95, height: 180)
        timunMas.center = CGPoint(x: 130, y: 360)
        timunMas.contentMode = .scaleToFill
        self.addSubview(timunMas)
        
        //rak
        rak.image = UIImage(named: "Elements/rak.png")
        rak.frame = CGRect(x: 280, y: 160, width: 380, height: 130)
        rak.center = CGPoint(x: 500, y: 230)
        rak.contentMode = .scaleToFill
        self.addSubview(rak)
        
        //pouch
        pouch.image = UIImage(named: "Elements/pouch.png")
        pouch.frame = CGRect(x: 0, y: 0, width: 150, height: 100)
        pouch.center = CGPoint(x: 500, y: 410)
        pouch.contentMode = .scaleToFill
        self.addSubview(pouch)
        
        //biji satuan
        biji.image = UIImage(named: "Elements/CucumberSeeds.png")
        biji.frame = CGRect(x: 100,
                            y: 100, width: 50, height: 50)
        biji.contentMode = .scaleToFill
        biji.center = CGPoint(x: 350, y: 130)
        biji.alpha = 1
        self.addSubview(biji)
        
        //gayung
        gayung.image = UIImage(named: "Elements/Gayung.png")
        gayung.frame = CGRect(x: 50,
                              y: 200, width: 100, height: 40)
        gayung.contentMode = .scaleToFill
        gayung.center = CGPoint(x: 500, y: 130)
        gayung.alpha = 1
        self.addSubview(gayung)
        
        //needles
        needles.image = UIImage(named: "Elements/needles.png")
        needles.frame = CGRect(x: 50,
                               y: 200, width: 80, height: 80)
        needles.center = CGPoint(x: 650, y: 130)
        needles.contentMode = .scaleToFill
        needles.alpha = 1
        self.addSubview(needles)
        
        //ayam
        ayam.image = UIImage(named: "Elements/ayam.png")
        ayam.frame = CGRect(x: 50,
                            y: 200, width: 80, height: 80)
        ayam.center = CGPoint(x: 350, y: 250)
        ayam.contentMode = .scaleToFill
        ayam.alpha = 1
        self.addSubview(ayam)
        
        //salt
        salt.image = UIImage(named: "Elements/salt.png")
        salt.frame = CGRect(x: 50,
                            y: 200, width: 100, height: 40)
        salt.center = CGPoint(x: 500, y: 250)
        salt.contentMode = .scaleToFill
        salt.alpha = 1
        self.addSubview(salt)
        
        //pisau
        pisau.image = UIImage(named: "Elements/pisau.png")
        pisau.frame = CGRect(x: 50,
                             y: 200, width: 100, height: 40)
        pisau.center = CGPoint(x: 650, y: 250)
        pisau.contentMode = .scaleToFill
        pisau.alpha = 1
        self.addSubview(pisau)
        
        //text
        textLabel.text = "Help Timun Mas put the right item from the list into the pocket!"
        textLabel.textAlignment = NSTextAlignment.center
        textLabel.textColor = UIColor.black
        textLabel.numberOfLines = 0
        textLabel.frame = CGRect(x: 0, y: 35, width: 600, height: 70)
        textLabel.center = CGPoint(x: frameWidth/2, y: 50)
        textLabel.font = UIFont.boldSystemFont(ofSize: 14)
        textLabel.alpha = 1
        textLabel.isHidden = false
        self.addSubview(textLabel)
        
        //next button
        nextButton.setTitle("next", for: .normal)
        nextButton.layer.backgroundColor = UIColor(red: 245/255.0,
                                                   green: 224/255.0,
                                                   blue: 163/255.0,
                                                   alpha: 1.0).cgColor
        nextButton.frame = CGRect(x: 150, y: 180, width: 80, height: 30)
        nextButton.center = CGPoint(x: 650, y: 470)
        nextButton.setTitleColor(.black, for: .normal)
        nextButton.titleLabel?.font = UIFont.boldSystemFont(ofSize: 14)
        nextButton.layer.shadowOpacity = 0.2
        nextButton.layer.shadowRadius = 1.0
        nextButton.layer.cornerRadius = 15.0
        nextButton.addTarget(self, action: #selector(startButtonPressed), for: .touchUpInside)
        nextButton.alpha = 0
        self.addSubview(nextButton)
        
        
        
    }
    
    //checking for match
    @objc func checkingForMatch(_ location: CGPoint, _ step: Int) {
        
        if salt.frame.intersects(pouch.frame){
            
            //if pouch.frame.contains(location)//salt.frame.intersects(pouch.frame){
            if (stepProcess == 3) {
                salt.alpha = 0
                salt.isHidden = false
                self.pageFlipSound()
                stepProcess = 3
            } else {
                salt.center = saltLocation
            }
            
        }
        if needles.frame.intersects(pouch.frame){
            //        if pouch.frame.contains(location){//needles.frame.intersects(pouch.frame){
            if(stepProcess == 2){
                needles.alpha = 0
                needles.isHidden = true
                self.nextButton.alpha = 1
                self.pageFlipSound()
                stepProcess = 3
            } else {
                needles.center = NeedlesLocation
            }
        }
        if biji.frame.intersects(pouch.frame){
            //        if pouch.frame.contains(location) {//biji.frame.intersects(pouch.frame) {
            if(stepProcess == 1){
                biji.alpha = 0
                biji.isHidden = true
                self.pageFlipSound()
                stepProcess = 2
            } else {
                biji.center = cucumberLocation
            }
        }
        
    }
    // tutup if
    // tutup checkingformatch
    
    //begin touch
    public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches {
            let location = touch.location(in: self)
            
            if biji.frame.contains(location) && stepProcess == 1 {
                biji.center = location
            }
            if needles.frame.contains(location) && stepProcess == 2 {
                stepProcess = 2
                needles.center = location
            }
            if salt.frame.contains(location) && stepProcess == 3 {
                stepProcess = 3
                salt.center = location }
        }
    } // tutup touchesbegan
    
    
    //touches moved
    public override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches {
            let location = touch.location(in: self)
            
            if biji.frame.contains(location) && stepProcess == 1 {
                biji.center = location
            }
            else if needles.frame.contains(location) && stepProcess == 2 {
                needles.center = location
            }
            else if salt.frame.contains(location) && stepProcess == 2 {
                salt.center = location
            }
        }
    } // tutup touches moved
    
    
    //touches ended
    public override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesMoved(touches, with: event)
        let touch = touches.first!
        let location = touch.location(in: self)
        checkingForMatch(location, stepProcess)
        //        self.stepProcess = 0
        //        checkingForMatch()
    } // tutup touches ended
    
    
    //startbuttonpressed
    @objc func startButtonPressed(sender: UIButton) {
        nextScreen()
    } // tutup func startbuttonpressed
    
    //see next screen
    func nextScreen() {
        self.playBattleSound()
        self.stopBgSound()
        self.removeFromSuperview()
        let nextScreenView = Showdown(scene: self)
        PlaygroundPage.current.liveView = nextScreenView
    } // tutup func next screen
    
} // tutup class

