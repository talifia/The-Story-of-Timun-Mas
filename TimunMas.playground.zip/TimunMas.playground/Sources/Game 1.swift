import Foundation
import UIKit
import PlaygroundSupport

public class PickGame1: UIView {
    var frameWidth = 750
    var frameHeight = 500
    
    //Background
    let backgroundBG = UIImageView()
    
    //Elements
    let tanahBG = UIImageView()
    let biji = UIImageView()
    let gayung = UIImageView()
    let bijiBanyak = UIImageView()
    let cucumbers = UIImageView()
    let goldenCucumbers = UIImageView()
    let bayiTimun = UIImageView()
    
    //people
    let mbokSirni = UIImageView()
    
    //Button & text
    let nextButton = UIButton()
    let textLabel = UILabel()
    let textLabel2 = UILabel()
    let textView = UIView()
    let hiddenButton = UIButton()
    let cucumberButton = UIButton()
    var introProcess = 0
    
    //people
    let timunMas = UIImageView()
    
    //location
    let cucumberLocation = CGPoint(x: 350, y: 130)
    let NeedlesLocation = CGPoint(x: 650, y: 130)
    let saltLocation = CGPoint(x: 500, y: 250)
    
    let bijiLocation = CGRect(x: 100,
                              y: 100, width: 50, height: 50)
    let gayungLocation = CGRect(x: 50,
                                y: 200, width: 100, height: 40)
    
    //process
    var stepProcess = 1
    
    public init(scene: UIView) {
        super.init(frame:CGRect(x: 0, y: 0, width: frameWidth, height: frameHeight))
        setupUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setupUI() {
        backgroundBG.backgroundColor = .init(red: 242.0/255.0, green: 233.0/255.0, blue: 207.0/255.0, alpha: 100.0)
        backgroundBG.frame = CGRect(x: 0, y: 0, width: frameWidth, height: frameWidth)
        backgroundBG.contentMode = .scaleToFill
        self.addSubview(backgroundBG)
        
        //text
        textLabel.text = "Mbok Sirni wants to plant the seeds. Drag the seeds to the ground!"
        textLabel.textAlignment = NSTextAlignment.center
        textLabel.textColor = UIColor.black
        textLabel.numberOfLines = 0
        textLabel.frame = CGRect(x: 0, y: 35, width: 600, height: 70)
        textLabel.center = CGPoint(x: frameWidth/2, y: 50)
        textLabel.font = UIFont.boldSystemFont(ofSize: 14)
        textLabel.alpha = 1
        self.addSubview(textLabel)
        
        //tanah
        tanahBG.image = UIImage(named: "Background/tanahBG.png")
        tanahBG.frame = CGRect(x: 170,
                               y: 230, width: 370, height: 350)
        tanahBG.center = CGPoint(x: frameWidth/2, y: frameHeight/2)
        tanahBG.contentMode = .scaleToFill
        tanahBG.alpha = 1
        self.addSubview(tanahBG)
        
        //biji satuan
        biji.image = UIImage(named: "Elements/CucumberSeeds.png")
        biji.frame = CGRect(x: 100,
                            y: 100, width: 50, height: 50)
        biji.contentMode = .scaleToFill
        biji.alpha = 1
        self.addSubview(biji)
        
        //biji all
        bijiBanyak.image = UIImage(named: "Elements/BIJIs.png")
        bijiBanyak.frame = CGRect(x: 170,
                                  y: 230, width: 260, height: 260)
        bijiBanyak.center = CGPoint(x: frameWidth/2, y: frameHeight/2)
        bijiBanyak.contentMode = .scaleToFill
        bijiBanyak.alpha = 0
        self.addSubview(bijiBanyak)
        
        //gayung
        gayung.image = UIImage(named: "Elements/Gayung.png")
        gayung.frame = CGRect(x: 50,
                              y: 200, width: 100, height: 40)
        gayung.contentMode = .scaleToFill
        gayung.alpha = 1
        self.addSubview(gayung)
        
        //timun all
        cucumbers.image = UIImage(named: "Elements/CucumbersBanyak.png")
        cucumbers.frame = CGRect(x: 170,
                                 y: 230, width: 290, height: 290)
        cucumbers.center = CGPoint(x: frameWidth/2, y: frameHeight/2)
        cucumbers.contentMode = .scaleToFill
        cucumbers.alpha = 0
        self.addSubview(cucumbers)
        
        //timun satuan
        goldenCucumbers.image = UIImage(named: "Elements/GoldenCucumber.png")
        goldenCucumbers.frame = CGRect(x: 170,
                                       y: 230, width: 80, height: 80)
        goldenCucumbers.center = CGPoint(x: frameWidth/2, y: frameHeight/2)
        goldenCucumbers.contentMode = .scaleToFill
        goldenCucumbers.alpha = 0
        self.addSubview(goldenCucumbers)
        
        //bayi
        bayiTimun.image = UIImage(named: "Characters/babyTimun.png")
        bayiTimun.frame = CGRect(x: 170,
                                 y: 230, width: 260, height: 260)
        bayiTimun.center = CGPoint(x: frameWidth/2, y: frameHeight/2)
        bayiTimun.contentMode = .scaleToFill
        bayiTimun.alpha = 0
        self.addSubview(bayiTimun)
        
        //mbok sirni
        mbokSirni.image = UIImage(named: "Characters/MbokSarmiPraying.png")
        mbokSirni.transform = CGAffineTransform(scaleX: -1, y: 1); //Flipped
        mbokSirni.frame = CGRect(x: 570,
                                 y: 230, width: 90, height: 210)
        mbokSirni.contentMode = .scaleToFill
        mbokSirni.alpha = 1
        self.addSubview(mbokSirni)
        
        //text view
        textView.frame = CGRect(x: 0, y: 380,width: 650, height: 80)
        textView.center = CGPoint(x: frameWidth/2, y: 440)
        textView.backgroundColor = .white
        textView.layer.cornerRadius = 30.0
        textView.alpha = 0
        self.addSubview(textView)
        
        //text2
        textLabel2.text = "Mbok Sirni is very happy to see a beautiful baby girl inside the cucumber. She then named the baby Timun Mas (it means Golden Cucumber)."
        textLabel2.textAlignment = NSTextAlignment.center
        textLabel2.textColor = UIColor.black
        textLabel2.numberOfLines = 0
        textLabel2.frame = CGRect(x: 20, y: 35, width: 600, height: 70)
        textLabel2.center = CGPoint(x: frameWidth/2, y: 440)
        textLabel2.font = UIFont(name: "Arial", size: 14.5)
        textLabel2.alpha = 0
        self.addSubview(textLabel2)
        
        //next button
        nextButton.setTitle("next", for: .normal)
        nextButton.layer.backgroundColor = UIColor(red: 245/255.0,
                                                   green: 224/255.0,
                                                   blue: 163/255.0,
                                                   alpha: 1.0).cgColor
        nextButton.frame = CGRect(x: 150, y: 180, width: 80, height: 30)
        nextButton.center = CGPoint(x: 650, y: 470)
        nextButton.setTitleColor(.black, for: .normal)
        nextButton.titleLabel?.font = UIFont.boldSystemFont(ofSize: 14)
        nextButton.layer.shadowOpacity = 0.2
        nextButton.layer.shadowRadius = 1.0
        nextButton.layer.cornerRadius = 15.0
        nextButton.addTarget(self, action: #selector(startButtonPressed), for: .touchUpInside)
        nextButton.alpha = 0
        self.addSubview(nextButton)
        
    }
    
    //func animate instro
    func animateScene() {
        if(stepProcess == 0) {
            UIView.animate(withDuration: 1.5, delay: 0, options: .curveEaseOut, animations: {
                self.textLabel.alpha = 0
            }, completion: nil)
            UIView.animate(withDuration: 3.5, delay: 0, options: .curveEaseOut, animations: {
                self.textLabel.alpha = 1
                self.textLabel.text = "Drag the cucumber seeds to the ground!"
            })
            { (completion) in
                Timer.scheduledTimer(withTimeInterval: 5, repeats: false, block: { (time) in
                    self.animateScene()
                })
            }
        } // if
        if(stepProcess == 1) {
            UIView.animate(withDuration: 1.5, delay: 0, options: .curveEaseOut, animations: {
                self.textLabel.alpha = 0
            }, completion: nil)
            UIView.animate(withDuration: 3, delay: 0, options: .curveEaseOut, animations: {
                self.textLabel.alpha = 1
                self.textLabel.text = "Help Mbok Sirni Water the Plants. Drag the water to the ground!"
            })
            { (completion) in
                Timer.scheduledTimer(withTimeInterval: 2.5, repeats: false, block: { (time) in
                    self.animateScene()
                })
            }
        }// if
        if(stepProcess == 2) {
            UIView.animate(withDuration: 1.5, delay: 0, options: .curveEaseOut, animations: {
                self.textLabel.alpha = 0
            }, completion: nil)
            UIView.animate(withDuration: 3, delay: 0, options: .curveEaseOut, animations: {
                self.textLabel.alpha = 1
                self.textLabel.text = "Congrats!"
            })
            { (completion) in
                Timer.scheduledTimer(withTimeInterval: 2.5, repeats: false, block: { (time) in
                    self.nextButton.alpha = 0
                })
            }
        }// if
        if(stepProcess == 3) {
            self.animateTanahOut()
            self.animateCucumbersOut()
            self.animateTimun2()
            UIView.animate(withDuration: 1.5, delay: 0, options: .curveEaseOut, animations: {
                self.textLabel.alpha = 0
            }, completion: nil)
            UIView.animate(withDuration: 3, delay: 0, options: .curveEaseOut, animations: {
                self.textLabel.alpha = 1
                self.textLabel.text = "I wonder what's inside it..."
            })
            { (completion) in
                Timer.scheduledTimer(withTimeInterval: 2.5, repeats: false, block: { (time) in
                })
                self.bayiTimun.alpha = 1
                self.animateBaby()
            }
        }
    } // animate intro
    
    //animate mbok sirni
    func animateMbokSirni() {
        UIView.animate(withDuration: 1.0, delay: 0.5, usingSpringWithDamping: 1.0, initialSpringVelocity: 1.0, options: UIView.AnimationOptions.curveEaseIn, animations: ({
            self.mbokSirni.frame = CGRect(x: 370,
                                          y: 230, width: 110, height: 220)
            self.mbokSirni.center = CGPoint (x: 400, y: 320)
            self.mbokSirni.alpha = 1
        }))
    }
    
    //animate biji
    func animateBiji() {
        UIView.animate(withDuration: 1.0, delay: 0.5, usingSpringWithDamping: 1.0, initialSpringVelocity: 1.0, options: UIView.AnimationOptions.curveEaseIn, animations: ({
            self.bijiBanyak.frame = CGRect(x: 170,
                                           y: 230, width: 260, height: 260)
            self.bijiBanyak.center = CGPoint(x: self.frameWidth/2, y: self.frameHeight/2)
            self.bijiBanyak.alpha = 1
        }))
    }
    
    //animate biji out
    func animateBijiOut() {
        UIView.animate(withDuration: 1.0, delay: 0.5, usingSpringWithDamping: 1.0, initialSpringVelocity: 1.0, options: UIView.AnimationOptions.curveEaseOut, animations: ({
            self.bijiBanyak.frame = CGRect(x: 170,
                                           y: 230, width: 260, height: 260)
            self.bijiBanyak.center = CGPoint(x: self.frameWidth/2, y: self.frameHeight/2)
            self.bijiBanyak.alpha = 0
        }))
    }
    
    //animate cucumbers
    func animateCucumbers() {
        UIView.animate(withDuration: 1.0, delay: 1.0, usingSpringWithDamping: 1.0, initialSpringVelocity: 1.0, options: UIView.AnimationOptions.curveEaseIn, animations: ({
            self.cucumbers.frame = CGRect(x: 170,
                                          y: 230, width: 290, height: 290)
            self.cucumbers.center = CGPoint(x: self.frameWidth/2, y: self.frameHeight/2)
            self.cucumbers.alpha = 1
        }))
    }
    
    //animate cucumbers Out
    func animateCucumbersOut() {
        UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 1.0, initialSpringVelocity: 1.0, options: UIView.AnimationOptions.curveEaseOut, animations: ({
            self.cucumbers.frame = CGRect(x: 170,
                                          y: 230, width: 290, height: 290)
            self.cucumbers.center = CGPoint(x: self.frameWidth/2, y: self.frameHeight/2)
            self.cucumbers.alpha = 0
        }))
    }
    
    
    //animate tanah out
    func animateTanahOut() {
        UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 1.0, initialSpringVelocity: 1.0, options: UIView.AnimationOptions.curveEaseOut, animations: ({
            self.tanahBG.frame = CGRect(x: 170,
                                        y: 230, width: 370, height: 350)
            self.tanahBG.center = CGPoint(x: self.frameWidth/2, y: self.frameHeight/2)
            self.tanahBG.alpha = 0
        }))
    }
    
    //animate timun satuan 1
    func animateTimun1() {
        UIView.animate(withDuration: 1.0, delay: 1.0, usingSpringWithDamping: 1.0, initialSpringVelocity: 1.0, options: UIView.AnimationOptions.curveEaseIn, animations: ({
            self.goldenCucumbers.frame = CGRect(x: 170,
                                                y: 230, width: 80, height: 80)
            self.goldenCucumbers.center = CGPoint(x: self.frameWidth/2, y: self.frameHeight/2)
            self.goldenCucumbers.alpha = 1
        }))
    }
    
    //animate timun satuan 2
    func animateTimun2() {
        UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 1.0, initialSpringVelocity: 1.0, options: UIView.AnimationOptions.curveEaseInOut, animations: ({
            self.goldenCucumbers.frame = CGRect(x: 170,
                                                y: 230, width: 160, height: 160)
            self.goldenCucumbers.center = CGPoint(x: self.frameWidth/2, y: self.frameHeight/2)
            self.goldenCucumbers.alpha = 1
        }))
    }
    
    //animate timun out
    func animateTimunOut() {
        UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 1.0, initialSpringVelocity: 1.0, options: UIView.AnimationOptions.curveEaseOut, animations: ({
            self.goldenCucumbers.frame = CGRect(x: 170,
                                                y: 230, width: 160, height: 160)
            self.goldenCucumbers.center = CGPoint(x: self.frameWidth/2, y: self.frameHeight/2)
            self.goldenCucumbers.alpha = 1
        }))
    }
    
    
    //animate baby timun
    func animateBabyTimun() {
        UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 1.0, initialSpringVelocity: 1.0, options: UIView.AnimationOptions.curveEaseIn, animations: ({
            self.bayiTimun.frame = CGRect(x: 170,
                                          y: 230, width: 260, height: 260)
            self.bayiTimun.center = CGPoint(x: self.frameWidth/2, y: self.frameHeight/2)
            self.bayiTimun.alpha = 1
        }))
    }
    
    //animate text
    func animateText() {
        UIView.animate(withDuration: 0.5, delay: 1.5, usingSpringWithDamping: 1.0, initialSpringVelocity: 1.0, options: UIView.AnimationOptions.curveEaseIn, animations: ({
            self.textLabel.text = "wow! there's a baby girl inside!"
        }))
    }
    
    //animate baby
    func animateBaby() {
        self.cheeringSound()
        animateText()
        self.textView.alpha = 1
        self.textLabel2.alpha = 1
        self.nextButton.alpha = 1
    }
    
    //checking for match
    @objc func checkingForMatch(_ location: CGPoint, _ step: Int) {
        
        if gayung.frame.intersects(tanahBG.frame){
            //        if pouch.frame.contains(location){//needles.frame.intersects(pouch.frame){
            if(stepProcess == 2){
                animateScene()
                self.animateBijiOut()
                self.animateCucumbers()
                self.animateTimun1()
                gayung.alpha = 0
                gayung.isHidden = true
                self.pourSound()
                stepProcess = 3
            } else {
                gayung.frame = gayungLocation
            }
        }
        if biji.frame.intersects(tanahBG.frame){
            //        if pouch.frame.contains(location) {//biji.frame.intersects(pouch.frame) {
            if(stepProcess == 1){
                animateScene()
                biji.alpha = 0
                biji.isHidden = true
                self.animateBiji()
                self.pageFlipSound()
                stepProcess = 2
            } else {
                biji.frame = bijiLocation
            }
        }
        
    }
    // tutup if
    // tutup checkingformatch
    
    //begin touch
    public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches {
            let location = touch.location(in: self)
            
            if biji.frame.contains(location) && stepProcess == 1 {
                biji.center = location
            }
            if gayung.frame.contains(location) && stepProcess == 2 {
                stepProcess = 2
                gayung.center = location
            }
        }
    }// tutup touchesbegan
    
    
    //touches moved
    public override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches {
            let location = touch.location(in: self)
            
            if biji.frame.contains(location) && stepProcess == 1 {
                biji.center = location
            }
            else if gayung.frame.contains(location) && stepProcess == 2 {
                gayung.center = location
            }
        }
    } // tutup touches moved
    
    
    //touches ended
    public override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesMoved(touches, with: event)
        let touch = touches.first!
        let location = touch.location(in: self)
        checkingForMatch(location, stepProcess)
    } // tutup touches ended
    
    
    @objc func startButtonPressed(sender: UIButton) {
        nextScreen()
    }
    
    func nextScreen() {
        //                //naro lagu
        ////                self.playBgSound()
        //
        self.removeFromSuperview()
        let nextScreenView = nextScene(scene: self)
        PlaygroundPage.current.liveView = nextScreenView
    }
}

