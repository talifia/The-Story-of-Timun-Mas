import Foundation
import UIKit
import PlaygroundSupport

public class Introduction: UIView {
    var frameWidth = 750
    var frameHeight = 500
    
    //Sky
    let backgroundBG = UIImageView()
    let cloudBG = UIImageView()
    let fogBG = UIImageView()
    
    //BG Element
    let mountainBG = UIImageView()
    let rockBG = UIImageView()
    let viewLantai = UIView()
    let houseAndTrees = UIImageView()
    let bubbleSpeech = UIImageView()
    let dedaunan1 = UIImageView()
    let dedaunan2 = UIImageView()
    
    //people
    let mbokSirni = UIImageView()
    let butoIjo = UIImageView()
    let bijiSpeech = UIImageView()
    
    //text and button
    let nextButton = UIButton()
    let introLabel = UILabel()
    let textView = UIView()
    var introProcess = 0
    
    public init(scene: UIView) {
        super.init(frame:CGRect(x: 0, y: 0, width: frameWidth, height: frameHeight))
        setupUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setupUI() {
        //sky
        backgroundBG.image = UIImage(named: "Sky/Sky.png")
        backgroundBG.frame = CGRect(x: 0, y: 0, width: frameWidth, height: frameHeight)
        backgroundBG.contentMode = .scaleToFill
        self.addSubview(backgroundBG)
        
        //awan
        cloudBG.image = UIImage(named: "Sky/Clouds.png")
        cloudBG.frame = CGRect(x: 0, y: 50, width: frameWidth, height: 450)
        cloudBG.contentMode = .scaleToFill
        cloudBG.alpha = 1
        self.addSubview(cloudBG)
        
        
        //gunung
        mountainBG.image = UIImage(named: "Background/Mountains1.png")
        mountainBG.frame = CGRect(x: 0, y: 120, width: frameWidth, height: 220)
        mountainBG.contentMode = .scaleToFill
        mountainBG.alpha = 1
        self.addSubview(mountainBG)
        
        //fog
        fogBG.image = UIImage(named: "Sky/Fog.png")
        fogBG.frame = CGRect(x: 0,
                             y: 250, width: frameWidth, height: 250)
        fogBG.contentMode = .scaleToFill
        fogBG.alpha = 1
        self.addSubview(fogBG)
        
        //house & trees
        houseAndTrees.image = UIImage(named: "Background/HouseTrees.png")
        houseAndTrees.frame = CGRect(x: 50, y: 160, width: 650, height: 220)
        houseAndTrees.contentMode = .scaleToFill
        self.addSubview(houseAndTrees)
        
        //lantai
        viewLantai.frame = CGRect(x: 0, y: 370,width: frameWidth, height: 200)
        viewLantai.layer.backgroundColor = UIColor(red: 105/255.0,
                                                   green: 166/255.0,
                                                   blue: 89/255.0,
                                                   alpha: 1.0).cgColor
        self.addSubview(viewLantai)
        
        //butoijo
        butoIjo.image = UIImage(named: "Characters/ButoIjo1.png")
        butoIjo.frame = CGRect(x: 500,
                               y: 140, width: 200, height: 300)
        butoIjo.contentMode = .scaleToFill
        butoIjo.alpha = 0
        self.addSubview(butoIjo)
        
        //bubble speech
        bubbleSpeech.image = UIImage(named: "Elements/bubbleSpeech1.png")
        bubbleSpeech.frame = CGRect(x: 335,
                                    y: 170, width: 100, height: 120)
        bubbleSpeech.contentMode = .scaleToFill
        bubbleSpeech.alpha = 0
        self.addSubview(bubbleSpeech)
        
        //mbok sirni
        mbokSirni.image = UIImage(named: "Characters/MbokSarmiPraying.png")
        mbokSirni.frame = CGRect(x: 170,
                                 y: 220, width: 90, height: 210)
        mbokSirni.center = CGPoint(x: 200, y: 310)
        mbokSirni.contentMode = .scaleToFill
        fogBG.alpha = 1
        self.addSubview(mbokSirni)
        
        //rocks
        rockBG.image = UIImage(named: "Background/Rocks1.png")
        rockBG.frame = CGRect(x: 0, y: 350, width: frameWidth, height: 150)
        rockBG.contentMode = .scaleToFill
        rockBG.alpha = 1
        self.addSubview(rockBG)
        
        //text view
        textView.frame = CGRect(x: 0, y: 380,width: 650, height: 80)
        textView.center = CGPoint(x: frameWidth/2, y: 440)
        textView.backgroundColor = .white
        textView.layer.cornerRadius = 30.0
        textView.alpha = 1
        self.addSubview(textView)
        
        //text
        introLabel.text = "Once upon a time, lived an old woman named Mbok Sirni. She lived by herself because her husband had long passed away and she had no children. Every day, she prayed so God would give her a child."
        introLabel.textAlignment = NSTextAlignment.center
        introLabel.textColor = UIColor.black
        introLabel.numberOfLines = 0
        introLabel.frame = CGRect(x: 20, y: 35, width: 600, height: 70)
        introLabel.center = CGPoint(x: frameWidth/2, y: 440)
        introLabel.font = UIFont(name: "Arial", size: 14.5)
        introLabel.alpha = 0
        self.addSubview(introLabel)
        
        //next button
        nextButton.setTitle("next", for: .normal)
        nextButton.layer.backgroundColor = UIColor(red: 245/255.0,
                                                   green: 224/255.0,
                                                   blue: 163/255.0,
                                                   alpha: 1.0).cgColor
        nextButton.frame = CGRect(x: 150, y: 180, width: 80, height: 30)
        nextButton.center = CGPoint(x: 650, y: 470)
        nextButton.setTitleColor(.black, for: .normal)
        nextButton.titleLabel?.font = UIFont.boldSystemFont(ofSize: 14)
        nextButton.layer.shadowOpacity = 0.2
        nextButton.layer.shadowRadius = 1.0
        nextButton.layer.cornerRadius = 15.0
        nextButton.addTarget(self, action: #selector(startButtonPressed), for: .touchUpInside)
        nextButton.alpha = 0
        self.addSubview(nextButton)
        
        //dedaunan 1
        dedaunan1.image = UIImage(named: "Elements/dedaunan1.png")
        dedaunan1.frame = CGRect(x: 0, y: 0, width: 700, height: 900)
        dedaunan1.center = CGPoint(x: 450, y: frameHeight/2)
        dedaunan1.contentMode = .scaleToFill
        dedaunan1.alpha = 1
        self.addSubview(dedaunan1)
        
        //dedaunan 2
        dedaunan2.image = UIImage(named: "Elements/dedaunan1.png")
        dedaunan2.frame = CGRect(x: 0, y: 0, width: 700, height: 900)
        dedaunan2.transform = CGAffineTransform(scaleX: -1, y: 1); //Flipped
        dedaunan2.center = CGPoint(x: 300, y: frameHeight/2)
        dedaunan2.contentMode = .scaleToFill
        dedaunan2.alpha = 1
        self.addSubview(dedaunan2)
        
        UIView.animateKeyframes(withDuration: 2.0, delay: 0.2){
            self.dedaunan1.frame = CGRect(x: 800, y: self.frameHeight/2, width: 700, height: 900)}
        
        UIView.animateKeyframes(withDuration: 2.0, delay: 0.2){
            self.dedaunan2.frame = CGRect(x: -500, y: self.frameHeight/2, width: 700, height: 900)}
        
        UIView.animateKeyframes(withDuration: 2.0, delay: 0, options: [.autoreverse, .repeat]){
            self.cloudBG.frame = CGRect(x: 0, y: 70, width: 750, height: 450)}
        
        //ANIMATE introduction
        animateIntro()
        
    }
    
    //func animate instro
    func animateIntro() {
        if(introProcess == 0)  {
            UIView.animate(withDuration: 3, delay: 1, options: .curveEaseOut, animations: {
                self.introLabel.alpha = 1
            })
            { (completion) in
                Timer.scheduledTimer(withTimeInterval: 3, repeats: false, block: { (time) in
                    self.introProcess = 1
                    self.animateIntro()
                    self.animateButoIjo()
                })
            }
        } // if
        if(introProcess == 1) {
            mbokSirni.image = UIImage(named: "Characters/MbokSirni_surprised.png")
            mbokSirni.frame = CGRect(x: 170,
                                     y: 220, width: 110, height: 230)
            mbokSirni.center = CGPoint(x: 200, y: 300)
            UIView.animate(withDuration: 1.5, delay: 0, options: .curveEaseOut, animations: {
                self.introLabel.alpha = 0
            }, completion: nil)
            //        UIView.animate(withDuration: 0.5, delay: 0, options: .curveEaseOut, animations: {
            //            self.butoIjo.alpha = 1
            //        }, completion: nil)
            UIView.animate(withDuration: 3.5, delay: 0, options: .curveEaseOut, animations: {
                self.introLabel.alpha = 1
                self.introLabel.text = "One night, when she was praying, a giant named Buto Ijo passed her house and heard her praying. 'I can give you a child on one condition,” Buto Ijo said to Mbok Sirni, “However, you must give the child back to me when she’s 17 years old. I would eat her as my dinner!"
            })
            { (completion) in
                Timer.scheduledTimer(withTimeInterval: 5, repeats: false, block: { (time) in
                    self.introProcess = 2
                    self.animateIntro()
                })
            }
        } // if
        if(introProcess == 2) {
            self.animateBubbleSpeech()
            UIView.animate(withDuration: 1.5, delay: 0, options: .curveEaseOut, animations: {
                self.introLabel.alpha = 0
            }, completion: nil)
            UIView.animate(withDuration: 3, delay: 0, options: .curveEaseOut, animations: {
                self.introLabel.alpha = 1
                self.introLabel.text = "Mbok Sirni was so happy; she did not think about the risk of losing the child later and agreed to take Buto Ijo’s offer. The giant then gave her a bunch of cucumber seeds. “Plant it around your house.” Buto Ijo then left without saying anything else."
            })
            { (completion) in
                Timer.scheduledTimer(withTimeInterval: 2.5, repeats: false, block: { (time) in
                    self.introProcess = 3
                    self.nextButton.alpha = 1
                })
            }
        }
    } // animate intro
    
    func animateButoIjo() {
        UIView.animate(withDuration: 1.0, delay: 0.5, usingSpringWithDamping: 1.0, initialSpringVelocity: 1.0, options: UIView.AnimationOptions.curveEaseIn, animations: ({
            self.butoIjo.frame = CGRect(x: 400,
                                        y: 150, width: 200, height: 300)
            self.butoIjo.alpha = 1
            self.butoIjoSound()
        }))
    }
    
    func animateBubbleSpeech() {
        UIView.animate(withDuration: 1.0, delay: 0.5, usingSpringWithDamping: 1.0, initialSpringVelocity: 1.0, options: UIView.AnimationOptions.curveEaseIn, animations: ({
            self.bubbleSpeech.frame = CGRect(x: 335,
                                             y: 180, width: 100, height: 120)
            self.bubbleSpeech.alpha = 1
        }))
    }
    
    @objc func startButtonPressed(sender: UIButton) {
        nextScreen()
    }
    
    func nextScreen() {
        //                //naro lagu
        ////                self.playBgSound()
        //
        self.removeFromSuperview()
        let gameView = PickGame1(scene: self)
        PlaygroundPage.current.liveView = gameView
    }
}


