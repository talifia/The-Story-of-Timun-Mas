import Foundation
import UIKit
import PlaygroundSupport

public class ButoIjoDrowned: UIView {
    var frameWidth = 750
    var frameHeight = 500
    
    //Background
    let backgroundBG = UIImageView()
    let cloudBG = UIImageView()
    let fogBG = UIImageView()
    
    //Elements
    let mountainBG = UIImageView()
    let rockBG = UIImageView()
    let viewLantai = UIView()
    let houseAndTrees = UIImageView()
    let bubbleSpeech = UIImageView()
    let laut1 = UIView()
    let laut2 = UIView()
    
    //people
    let butoIjo = UIImageView()
    let timunMas = UIImageView()
    
    //Button & text
    let nextButton = UIButton()
    let nextButton2 = UIButton()
    let saltButton = UIButton()
    let needlesButton = UIButton()
    let cucumberButton = UIButton()
    let textLabel = UILabel()
    let textView = UIView()
    
    public init(scene: UIView) {
        super.init(frame:CGRect(x: 0, y: 0, width: frameWidth, height: frameHeight))
        setupUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setupUI() {
        //sky
        backgroundBG.image = UIImage(named: "Sky/Sky6.png")
        backgroundBG.frame = CGRect(x: 0, y: 0, width: frameWidth, height: frameWidth)
        backgroundBG.contentMode = .scaleToFill
        self.addSubview(backgroundBG)
        
        
        //awan
        cloudBG.image = UIImage(named: "Sky/Clouds.png")
        cloudBG.frame = CGRect(x: 0, y: 50, width: frameWidth, height: 450)
        cloudBG.contentMode = .scaleToFill
        self.addSubview(cloudBG)
        
        
        //fog
        fogBG.image = UIImage(named: "Sky/Fog.png")
        fogBG.frame = CGRect(x: 0,
                             y: 270, width: frameWidth, height: 250)
        fogBG.contentMode = .scaleToFill
        self.addSubview(fogBG)
        
        
        //gunung
        mountainBG.image = UIImage(named: "Background/mountains2.png")
        mountainBG.frame = CGRect(x: 0, y: 0, width: 1000, height: 500)
        mountainBG.center = CGPoint(x: frameWidth/2, y: 150)
        mountainBG.contentMode = .scaleToFill
        self.addSubview(mountainBG)
        
        //trees
        houseAndTrees.image = UIImage(named: "Background/trees.png")
        houseAndTrees.frame = CGRect(x: 0, y: 200, width: frameWidth, height: 220)
        houseAndTrees.contentMode = .scaleToFill
        self.addSubview(houseAndTrees)
        
        //text
        textLabel.text = "After trying to stay afloat, Buto Ijo drowned and died."
        textLabel.textAlignment = NSTextAlignment.center
        textLabel.textColor = UIColor.black
        textLabel.numberOfLines = 0
        textLabel.frame = CGRect(x: 0, y: 35, width: 600, height: 70)
        textLabel.center = CGPoint(x: frameWidth/2, y: 50)
        textLabel.font = UIFont.boldSystemFont(ofSize: 14)
        textLabel.alpha = 1
        self.addSubview(textLabel)
        
        
        //laut
        laut1.frame = CGRect(x: 0, y: 320, width: frameWidth, height: 120)
        laut1.layer.backgroundColor = UIColor(red: 118/255.0,
                                              green: 247/255.0,
                                              blue: 229/255.0,
                                              alpha: 1.0).cgColor
        laut1.alpha = 1
        self.addSubview(laut1)
        
        
        
        //buto ijo
        butoIjo.image = UIImage(named: "Characters/ButoIjo3.png")
        butoIjo.frame = CGRect(x: 200,
                               y: 100, width: 320, height: 340)
        butoIjo.contentMode = .scaleToFill
        butoIjo.alpha = 0
        self.addSubview(butoIjo)
        
        //laut 2
        laut2.frame = CGRect(x: 0, y: 400,width: frameWidth, height: 120)
        laut2.layer.backgroundColor = UIColor(red: 118/255.0,
                                              green: 247/255.0,
                                              blue: 229/255.0,
                                              alpha: 1.0).cgColor
        laut2.alpha = 1
        self.addSubview(laut2)
        
        //bubble speech
        bubbleSpeech.image = UIImage(named: "Elements/bubbleSpeech4.png")
        bubbleSpeech.frame = CGRect(x: 335,
                                    y: 170, width: 140, height: 120)
        bubbleSpeech.center = CGPoint(x: 600, y: 100)
        bubbleSpeech.contentMode = .scaleToFill
        bubbleSpeech.alpha = 0
        self.addSubview(bubbleSpeech)
        
        
        //next button
        nextButton.setTitle("Next!", for: .normal)
        nextButton.layer.backgroundColor = UIColor(red: 245/255.0,
                                                   green: 224/255.0,
                                                   blue: 163/255.0,
                                                   alpha: 1.0).cgColor
        nextButton.frame = CGRect(x: 150, y: 180, width: 80, height: 30)
        nextButton.center = CGPoint(x: 630, y: 470)
        nextButton.setTitleColor(.black, for: .normal)
        nextButton.titleLabel?.font = UIFont.boldSystemFont(ofSize: 14)
        nextButton.layer.shadowOpacity = 0.2
        nextButton.layer.shadowRadius = 1.0
        nextButton.layer.cornerRadius = 15.0
        nextButton.addTarget(self, action: #selector(startButtonPressed), for: .touchUpInside)
        nextButton.alpha = 0
        self.addSubview(nextButton)
        
        UIView.animateKeyframes(withDuration: 2.0, delay: 0, options: [.autoreverse, .repeat]){
            self.cloudBG.frame = CGRect(x: 0, y: 70, width: 750, height: 450)}
        
        
        animatebutton()
        animatebutoijo()
    }
    
    
    func animatebutton() {
        UIView.animate(withDuration: 0.5, delay: 2.5, usingSpringWithDamping: 1.0, initialSpringVelocity: 1.0, options: UIView.AnimationOptions.curveEaseIn, animations: ({
            self.nextButton.frame = CGRect(x: 150, y: 180, width: 150, height: 30)
            self.nextButton.center = CGPoint(x: 630, y: 470)
            self.nextButton.alpha = 1
        }))
    }
    
    func animatebutoijo() {
        self.waterkSound()
        UIView.animate(withDuration: 5, delay: 0.5, usingSpringWithDamping: 1.0, initialSpringVelocity: 0.2, options: UIView.AnimationOptions.curveEaseIn, animations: ({
            self.butoIjo.frame = CGRect(x: 200,
                                        y: 500, width: 320, height: 340)
            self.butoIjo.alpha = 1
        }))
    }
    
    @objc func startButtonPressed(sender: UIButton) {
        nextScreen()
    }
    
    
    
    
    func nextScreen() {
        self.cheeringSound()
        self.removeFromSuperview()
        let nextScreenView = Congrats(scene: self)
        PlaygroundPage.current.liveView = nextScreenView
    }
}
