/*:
 # THE STORY OF TIMUN MAS
 ### About This Work
 Hi! 😄 My name is Tsamara Alifia and I am from Jakarta, Indonesia. I am currently a learner at Apple Developer @ Infinite Learning Batam.
 
 The Story of Timun Mas is a game featuring a Javanese folklore: Timun Mas. It is a story of a brave girl named Timun Mas that tries to escape and survive from an evil green giant that tried to catch and eat her.
 
 I grew up reading tons of local folklore stories from various regions from Indonesia. Timun Mas is one of the earliest stories I read and have a special place in a lot of indonesian children's heart, including me. This story teaches us about responsibility, hope, and resilience. This playground was made with the hope for people to enjoy the story while learning the moral values using simple interactive game.
 
 I hope you can enjoy this playground as much as I enjoy creating it! Have fun 😆
 
 ### How To Play
 The game is very easy. You just have to follow the instruction from the game. Expand the screen for a better viewing experience. Just sit, relax, and enjoy the story!
 
 *Caution: There would be sections where you have to drag items to the designated area. Please follow the pace of the game and don't drag the items too fast nor too slow.*
 
## CREDITS
 ### Sound
 * The song featured in this game is titled: "Suwe Ora Jamu", a traditional Indonesian song from Java. The sound was made by myself using garage band.
 
 * The sound for Kids Cheering (Assets/kids_cheering_imovie.m4a), suspense (Assets/Suspense.mp3) & water wave (Assets/Water Sound.mp3) are from iLife Sound Effect from iMovie
 
 ### Image Assets
 * The mountain and trees assets were downloaded from the [Kenney](https://www.kenney.nl) Background Elements package under the CC0 license.
 
 * The bamboo tree asset was made by Guilherme franco and downloaded from [SVG-clipart](https://svg-clipart.com/) for free.
 
 * The batik pattern used in this game is called the Kawung. Originated in Java, the Kawung is one of the oldest Batik motifs. You can read more about the Kawung [here](https://marinaelphick.com/2014/02/17/kawung-batik-motif/comment-page-1/). The pattern was made using sketch.


Enjoy! 😄
*/

import UIKit
import PlaygroundSupport

var view = UIView()
var welcomeView = Welcome(scene: view)

PlaygroundPage.current.needsIndefiniteExecution = true
PlaygroundPage.current.liveView = welcomeView
